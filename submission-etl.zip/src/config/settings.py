"""
Configuration settings for the ETL pipeline
"""

# PostgreSQL database settings
POSTGRES_HOST = "localhost"
POSTGRES_PORT = "5432"
POSTGRES_DB = "fashion_db"
POSTGRES_USER = "alfan"
POSTGRES_PASSWORD = "alfan"
POSTGRES_TABLE = "products"

# Google Sheets settings
GOOGLE_CREDENTIALS_PATH = "ippl-456718-fb0b0bbf80ab.json"
GOOGLE_SPREADSHEET_ID = "1GJEZrcKUGkNRbj0xmSqAVupd7xwMLPJMVUWX3p36RT8"

# CSV settings
CSV_OUTPUT_PATH = "products.csv"

# Scraping settings
TARGET_URL = "https://fashion-studio.dicoding.dev/"
MAX_PAGES = 50
MAX_PRODUCTS = 1000
PAGE_DELAY = 0.5  # seconds between page requests

API_KEY = "your_api_key_here"
DATABASE_URL = "your_database_url_here"
LOG_LEVEL = "INFO"
TIMEOUT = 30  # seconds
RETRY_COUNT = 3  # number of retries for network requests